# OSRIP — Claude Code implementation instructions (8 November 2026)

Repository: https://github.com/azanalmasaoudi-cyber/OSRIP

Attached project material:
- `OSRIP_Academic_Booklet_Rewritten_Nov_2026_60_Pages.docx`
- `OSRIP_Academic_Booklet_Rewritten_Nov_2026_60_Pages.pdf`
- `OSRIP_2026_Latest_Statistics_Through_October.xlsx`
- `OSRIP_Oman_Annual_Research_Published_2026.xlsx`

## Command 1 — Implement Al Mulhim and the updated OSRIP requirements

Act as the senior full-stack engineer for the EXISTING OSRIP repository. Read the attached revised 60-page academic booklet as the project requirements and the current repository as the actual implementation state. Never claim a proposed feature is already working without tests.

1. Inspect the current FastAPI, React, PostgreSQL, provider, streaming, GIS, account and reporting implementations before making changes. Preserve data and existing functioning routes.
2. Retain **Al Mulhim / الملهم** as the ONLY active AI persona. Remove Ilham's visible selection, old imagery and dead navigation without deleting historical research records. Replace every old assistant view with the current premium Al Mulhim design, fully supporting Arabic/English and dark/light themes.
3. Make conversation output arrive through genuine backend-to-frontend streaming (SSE or another compatible supported transport). Show meaningful states: searching, reading, analyzing, writing, completed. Incrementally display actual model text as produced rather than pasting a completed answer or simulating a typing effect. Support Stop, Retry and failure recovery. Do not reveal private reasoning or claim a separate hidden thought transcript.
4. Implement three distinct modes: **Quick Answer**, **Deep Internet Research**, and **Data Analysis & Visualization**. Restrict available tools per mode. In independent Internet Research mode, use current external web information and DO NOT invoke OSRIP's internal observational datasets or silently substitute cached project statistics. Internal Data Analysis uses only the user-selected approved data.
5. For deep research, retrieve relevant original external documents, compare publishers and dates, validate units and geographic coverage, perform deterministic numeric calculations and write original coherent reports in natural Arabic or English. Do not copy/paste web excerpts. Produce usable tables, charts, scenario explanations, shortage/surplus analysis and practical trade recommendations when evidence supports them. Never invent wilayat-level metrics.
6. Remove automatic bulky `Sources (N)` panels and raw `[E...]` evidence dumps from normal chat. Allow explicit 'show sources' / 'اعرض المصادر' requests to show answer-specific evidence. Preserve backend audit records and keep mandatory provider licensing/attribution citations clickable where required.
7. Investigate `Answer withheld`: retain valid supported parts of an answer and omit or qualify unsupported claims; do not disable factual verification.
8. Rework authentication to **username + password**, with no mandatory email or telephone fields. Implement secure signup, hashing, backend authorization, sessions and verified recovery. Preserve existing users and administrator Azzan; NEVER allow an arbitrary user to become administrator by choosing the name Azzan.
9. Use the supplied design and original sector cards to refresh the cinematic OSRIP intro, single-assistant screen, dashboard, navigation and login. Maintain RTL/LTR, responsive layout and reduced-motion support.
10. Integrate the supplied NCSI-based workbooks through the existing controlled import and approval pipeline. Distinguish the complete-year 2021-2025 series from separately labelled January-September 2026 electricity/water, January-August trade and January-June fisheries. The NCSI October 2026 bulletin's publication month is not proof that all indicators cover October. Never assign national or governorate values to wilayats.
11. Preserve MapLibre, add a licensed Oman-specific terrain/satellite provider only if configured, and connect all 11 governorates / 63 wilayats to verified boundary geometry. Never activate paid accounts without explicit authorization.
12. Add regression tests for streaming, mode isolation, Arabic/English, provenance visibility, wrong-password rejection, role escalation, verified/partial-year periods, data tables/charts and GIS no-data states. Validate actual provider configuration; scripted or mocked tests are not live API tests.
13. Work in a new development branch. Commit verified stages, push the branch, open a Pull Request for review, and DO NOT merge to main without approval. Do not force push, hardcode secrets, or incur charges without permission.

Deliver: completed/pending feature checklist, real test results, measured latency for short and deep questions, changed files, actual provider readiness, branch and PR URL, and instructions for keys or credentials I must configure myself.

## Command 2 — Keep the academic booklet aligned with the software

Read the attached revised academic booklet (exactly 60 pages in the supplied PDF), its references, statistical appendices and project-status distinctions. After implementation, compare all software claims with actual repository code and verified tests. Propose edits where completed features or remaining limitations differ. Keep the booklet in formal English, preserve academic integrity, the five main chapters and exactly 60 pages. Maintain source citations in the academic booklet even if ordinary OSRIP assistant answers collapse bulk source lists. Do not invent participant studies, supervisor signatures, deployments or user metrics. Differentiate 2025 complete-year data from preliminary 2026 partial-year reports; keep the 2026 publication date and each observation period separate. Provide an updated editable DOCX and a rendered 60-page PDF after visual QA. Save documentation changes to the development branch for review, without merging automatically.
