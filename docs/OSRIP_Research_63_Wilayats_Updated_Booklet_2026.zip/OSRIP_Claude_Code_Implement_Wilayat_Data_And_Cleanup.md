# CLAUDE CODE — OSRIP: WILAYAT EVIDENCE, LEAN PLATFORM CLEANUP & BOOKLET SYNC

Repository: https://github.com/azanalmasaoudi-cyber/OSRIP

Use the attached research workbook and the revised academic booklet. This is an EXISTING React/TypeScript, FastAPI and PostgreSQL project. Do not rebuild it, replace the dataset with invented values, or delete existing production records.

## Phase 0 — Safety and verified inventory

1. Inspect the current default branch, migrations, frontend routes, backend tool routing, tests, public assets and existing database schema.
2. Create a feature branch and a rollback plan. Never force push or merge into main without explicit permission.
3. Identify every component referencing Ilham, `TalkPage`, `/talk`, duplicate assistant panels, old demo banners, obsolete assets and redundant navigation. List the references and evaluate migration impact before removal.
4. Keep historical user conversations, identifiers, role permissions, passwords and audit records intact. Do not hardcode credentials. No paid APIs or subscriptions without separate approval.
5. Distinguish implemented and live-tested functionality from code present without verified credentials.

## Phase 1 — Ingest the evidence workbook correctly

Read `OSRIP_Wilayat_Evidence_Development_Review_2026.xlsx` and validate all sheets:
- `Wilayats_63`: 63 population records for 2024 and 2025 (national 2025 total = 5,359,557).
- `Trade_Wilayat_Events`: 39 separately sourced rows across different metric types and periods. Exactly 24 rows are 2025 full-year new commercial registrations; the rest are Q1/Q2 2026 new registrations or cumulative stocks. NEVER aggregate these categories as one metric.
- `Water_Governorates`: 2024–2025 water production and distribution at governorate level only. Do not assign the figures to individual wilayats or interpret production-minus-distribution as unaccounted-for water automatically.
- `Annual_National`: complete-year indicators and explicit source/provider coverage; Nama Water Services operational coverage excludes Dhofar.
- `2026_Interim`: preliminary January–September or other partial periods, never annual 2026 data.
- `Axis_Coverage_252`: four-sector coverage status for all 63 wilayats; missing values are NULL, not zero.
- `Source_Register`: preserve official URLs internally and in compliance/audit records.

Use a staging import, schema validation, idempotent source IDs and locality IDs, explicit measurement definitions, units, publication dates, period types, scope, approval status and dataset versions. Build a reviewer preview and publish only after authorized approval; provide dry-run and rollback paths. Reconcile all 63 population rows and totals. For old datasets, never overwrite verified records without controlled revision logic.

## Phase 2 — One excellent bilingual assistant: Al Mulhim only

Remove Ilham from the ACTIVE visible user experience (picker, welcome screen, new assistant sessions and active controls), while preserving historical records and safe compatibility for old messages. Consolidate all assistant entry points at `/assistant`. Redirect legacy `/talk` links to the new chat without breaking saved deep links. Integrate optional microphone controls into the new composer; do not preserve a second call-screen UI.

Use a coherent charcoal/peach glassmorphism design, Arabic RTL and English LTR, high-contrast light/dark themes, responsive modern message rendering, inline analytical tables, validated charts, genuine streamed output, Stop, Retry and good waiting states. Avoid fake typewriter animation from a completed response.

In explicitly selected Internet Research mode, separate web research tools from OSRIP internal database tools; do not silently substitute the internal observations. Retain Quick Answer and Internal Data Analysis as distinct tool policies inside ONE user interface. Write original, substantial analyses with meaningful conclusions rather than copying search snippets. Preserve uncertainty and data provenance. Never invent statistics, geographic data, forecasts or investment profitability.

Do not render large `Sources (105)` panels or raw evidence IDs beneath ordinary replies. Permit source requests in Arabic and English and preserve provider-required attribution and legally required citations. Repair whole-answer withholding by validating or qualifying individual claims, never disabling factual validation or authorization.

## Phase 3 — Remove unnecessary UI and modules safely

- Remove the Ilham picker and duplicate persona UI after compatibility tests.
- Replace the old TalkPage experience with one redirect and unified chat.
- Consolidate duplicate data, scenarios, research and analysis navigation into a small set of logically nested modules.
- Keep synthetic/demo indicators ONLY in explicit demonstration mode. They must never appear as current verified statistics.
- Keep admin Data Management, Groups/Roles and Service Health behind real backend permission checks.
- Identify unreferenced visual assets, stale components, styles, and redundant routes using dependency and usage analysis. Delete only confirmed unused files after tests, not by filename alone.
- Preserve public route redirects, accessibility and historical user content.

Do not delete source evidence, academic references, required legal attributions, database migrations, operating backups, authentication logic or security checks.

## Phase 4 — Oman map and four-sector intelligence

Show 11 governorates and 63 wilayats using verified spatial boundaries and allowed map/terrain tiles; keep Musandam. Use a no-data legend for wilayats lacking actual electricity, water or agricultural values. Display full-year population and verified dated trade counts by wilayat, and aggregate water only at its true governorate scope. Each tooltip must show indicator, period, unit, source/provider coverage and validation status.

Expose one user flow: Axis → Indicator → Year/period → Governorate/Wilayat → Map/Table/Chart → Al Mulhim explanation → Report. Distinguish observed facts from hypotheses and recommendation opportunities. For trade, require demand, commodity/HS code, logistics, costs, capacity and competition to justify any investment suggestion.

## Phase 5 — Speed, tests and version control

Instrument p50/p95 time to first output, search latency, token streaming latency, chart render latency and API budget. Use targeted caching, lazy loading, cancellation, prompt/tool routing and concurrency safely. Do not invent benchmark results.

Run frontend type checks and builds; backend unit/integration tests; the real auth and role checks; migration dry-run; 63-unit locality reconciliation; 2025 annual-versus-2026-quarter separation; 252 status checks; assistant mode isolation; old `/talk` redirect; persona-history preservation; Arabic/English tests; mobile view; empty data; map no-data state; provenance access; source attribution compliance.

Commit tested changes to the feature branch and create a pull request. Do not merge main without approval. Report paths changed, migrations, tests actually run, unsuccessful checks, provider keys still required, and source links in internal documentation.

## Phase 6 — Academic booklet synchronization

Use `OSRIP_Academic_Booklet_Expanded_2026_Wilayat_Research.docx` (69-page research version). Compare EVERY claim about implementation with tested code. Update proposed vs implemented labels only after tests. Preserve five chapters, tables, scholarly provenance, 63-wilayat appendices and 2026 interim caveats. Keep the final document at or under 70 pages. Export DOCX and PDF and visually inspect the final PDF pagination.

**Do the work in code, not just a plan.** Never report a successful feature, import, data refresh, deployment, integration or GitHub push unless it actually occurred.
